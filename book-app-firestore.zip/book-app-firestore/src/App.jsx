// ============================================
// App.jsx - Main Application Component
// Connects everything together
// ============================================

import React, { useState, useEffect } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "./firebase";
import AddStudent from "./components/AddStudent";
import StudentList from "./components/StudentList";
import EditStudent from "./components/EditStudent";
import "./App.css";

function App() {
  // ── State ──────────────────────────────────
  const [students, setStudents] = useState([]);
  const [editingStudent, setEditingStudent] = useState(null); // null = not editing

  // ── Fetch all students from Firestore ──────
  const fetchStudents = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "students"));
      const studentsList = querySnapshot.docs.map((doc) => ({
        id: doc.id,       // Firestore document ID
        ...doc.data(),    // name, email, course
      }));
      setStudents(studentsList);
    } catch (error) {
      console.error("Error fetching students:", error);
    }
  };

  // ── Fetch students when app loads ──────────
  useEffect(() => {
    fetchStudents();
  }, []);

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <h1>Student Manager Project</h1>
        <p>CRUD Operations with React & Firebase</p>
      </header>

      <div className="container">
        {/* Show Edit form OR Add form */}
        {editingStudent ? (
          <EditStudent
            student={editingStudent}
            onUpdated={() => {
              setEditingStudent(null);
              fetchStudents();
            }}
            onCancel={() => setEditingStudent(null)}
          />
        ) : (
          <AddStudent onStudentAdded={fetchStudents} />
        )}

        {/* Student List */}
        <StudentList
          students={students}
          onDelete={fetchStudents}
          onEdit={(student) => setEditingStudent(student)}
        />
      </div>
    </div>
  );
}

export default App;
