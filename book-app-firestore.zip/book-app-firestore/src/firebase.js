// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDPjFnCTap7p0n7S964WYrf97TcZHgdwn8",
  authDomain: "studentcrud-87fda.firebaseapp.com",
  projectId: "studentcrud-87fda",
  storageBucket: "studentcrud-87fda.firebasestorage.app",
  messagingSenderId: "552526015909",
  appId: "1:552526015909:web:36e4742b2483b7dd1e0c4c",
  measurementId: "G-N4EJP6MYW2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore (our database)
const db = getFirestore(app);

export { db };