# Assignment 1: React CRUD with Firebase

A simple React app to perform **Create, Read, Update, Delete** operations using Firebase Firestore.

---

## 📁 Folder Structure

```
Assignment1/
├── src/
│   ├── components/
│   │   ├── AddStudent.jsx     # Form to add a new student (CREATE)
│   │   ├── StudentList.jsx    # Table showing all students (READ + DELETE)
│   │   └── EditStudent.jsx    # Form to edit a student (UPDATE)
│   ├── firebase.js            # Firebase configuration
│   ├── App.jsx                # Main component
│   ├── App.css                # App styles
│   ├── main.jsx               # Entry point
│   └── index.css              # Global styles
├── package.json
└── README.md
```

---

## 🔥 Firebase Setup (Do This First!)

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Click **"Create a project"** → give it a name → continue
3. Go to **Project Settings** (⚙️ icon) → **General** → scroll down → **Add app** → choose **Web (</>) **
4. Copy the `firebaseConfig` object
5. Paste it in `src/firebase.js` (replace the placeholder values)
6. Go to **Firestore Database** → **Create Database** → choose **Start in Test Mode** → Done

---

## 🚀 How to Run

```bash
# 1. Install dependencies
npm install

# 2. Start the app
npm run dev
```

Open `http://localhost:5173` in your browser.

---

## 🧩 CRUD Operations Explained

| Operation  | Firebase Method    | Component          | What it does               |
| ---------- | ------------------ | ------------------ | -------------------------- |
| **Create** | `addDoc()`         | `AddStudent.jsx`   | Adds student to Firestore  |
| **Read**   | `getDocs()`        | `App.jsx`          | Fetches all students       |
| **Update** | `updateDoc()`      | `EditStudent.jsx`  | Updates student data       |
| **Delete** | `deleteDoc()`      | `StudentList.jsx`  | Deletes a student          |

---

## 🔧 Technologies Used

- **React.js** — UI library
- **Vite** — Build tool
- **Firebase Firestore** — Cloud NoSQL database
