// ============================================
// AddStudent Component
// A form to add a new student to Firestore
// ============================================

import React, { useState } from "react";
import { collection, addDoc } from "firebase/firestore";
import { db } from "../firebase";

const AddStudent = ({ onStudentAdded }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [course, setCourse] = useState("");

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Add a new document to "students" collection in Firestore
      await addDoc(collection(db, "students"), {
        name,
        email,
        course,
      });

      // Clear the form
      setName("");
      setEmail("");
      setCourse("");

      // Tell parent component to refresh the list
      onStudentAdded();

      alert("Student added successfully! ✅");
    } catch (error) {
      console.error("Error adding student:", error);
      alert("Error adding student ❌");
    }
  };

  return (
    <div className="form-card">
      <h2>➕ Add New Student</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Student Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="email"
          placeholder="Email Address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Course (e.g. BCA, MCA)"
          value={course}
          onChange={(e) => setCourse(e.target.value)}
          required
        />
        <button type="submit" className="btn btn-add">
          Add Student
        </button>
      </form>
    </div>
  );
};

export default AddStudent;
