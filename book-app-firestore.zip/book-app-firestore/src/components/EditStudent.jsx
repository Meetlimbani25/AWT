// ============================================
// EditStudent Component
// A form to edit an existing student
// ============================================

import React, { useState } from "react";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

const EditStudent = ({ student, onUpdated, onCancel }) => {
  const [name, setName] = useState(student.name);
  const [email, setEmail] = useState(student.email);
  const [course, setCourse] = useState(student.course);

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Update the document in Firestore
      const studentRef = doc(db, "students", student.id);
      await updateDoc(studentRef, { name, email, course });

      onUpdated(); // Refresh the list
      alert("Student updated! ✅");
    } catch (error) {
      console.error("Error updating:", error);
      alert("Error updating student ❌");
    }
  };

  return (
    <div className="form-card edit-card">
      <h2>✏️ Edit Student</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Student Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="email"
          placeholder="Email Address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Course"
          value={course}
          onChange={(e) => setCourse(e.target.value)}
          required
        />
        <div className="edit-actions">
          <button type="submit" className="btn btn-add">
            Update
          </button>
          <button type="button" className="btn btn-cancel" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditStudent;
