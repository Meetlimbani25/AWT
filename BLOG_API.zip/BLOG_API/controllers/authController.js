const authService = require('../services/authService');


class AuthController {
    async registerUser(req, res) {
        authService.registerUser(req.res)
            let ret = await authService.registerUser(req.body);
            if (typeof (ret) === 'string') {
                res.jeson({
                    status: 'Error',
                    message: 'problem in the registration process !'
                })
        }else{
            res.json({
                status: 'Success',
                message: 'User registered successfully !'
            })
        }
    }
}

module.exports = new AuthController();