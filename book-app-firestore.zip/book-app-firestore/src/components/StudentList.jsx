// ============================================
// StudentList Component
// Displays all students from Firestore
// with Edit and Delete buttons
// ============================================

import React from "react";
import { doc, deleteDoc } from "firebase/firestore";
import { db } from "../firebase";

const StudentList = ({ students, onDelete, onEdit }) => {
  // Handle delete
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this student?");
    if (!confirmDelete) return;

    try {
      // Delete document from Firestore
      await deleteDoc(doc(db, "students", id));
      onDelete(); // Refresh the list
      alert("Student deleted! 🗑️");
    } catch (error) {
      console.error("Error deleting:", error);
      alert("Error deleting student ❌");
    }
  };

  return (
    <div className="list-card">
      <h2>📋 Student List</h2>

      {students.length === 0 ? (
        <p className="empty-msg">No students found. Add one above! ☝️</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              <th>Course</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student, index) => (
              <tr key={student.id}>
                <td>{index + 1}</td>
                <td>{student.name}</td>
                <td>{student.email}</td>
                <td>{student.course}</td>
                <td className="actions">
                  <button
                    className="btn btn-edit"
                    onClick={() => onEdit(student)}
                  >
                    ✏️ Edit
                  </button>
                  <button
                    className="btn btn-delete"
                    onClick={() => handleDelete(student.id)}
                  >
                    🗑️ Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default StudentList;
